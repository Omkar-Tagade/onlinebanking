<html>
<body background="img/Background_2560x1440.jpg">
<style>

h3{
	text-align:center;
	display:block;
	margin:auto;
	font-size : 5vh;
}
.server_down{
	
	/background-color: gray;
	width:100%;
	margin:5% auto;
}
img{
	margin:auto;
	display:block;
	border-radius:30px;
}
</style>
<h3>Server Down</h3>
<div class="server_down">
<img src="img/maintenance/server_down2.gif" align="middle" height ="330px" width = "440px" />

</div>


<body>
</html>